/* [ ---- Gebo Admin Panel - user profile ---- ] */

	$(document).ready(function() {
		//* enhanced select
		$("#user_languages").chosen();
		//* textarea autosize
		$('#u_signature').autosize();
	});
